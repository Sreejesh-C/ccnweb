<?php
// Include PhpSpreadsheet
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Include your database connection
include 'db.php'; // assuming db.php contains the DB connection

if (isset($_POST['download'])) {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Query to get data between the specified date range
    $sql = "SELECT modem_vendor, mac_address, complaint_type, power_status, booting_status, 
            lan_port_status, wlan_status, web_login, comment, entered_by, complaint_date 
            FROM complaints 
            WHERE complaint_date BETWEEN '$start_date' AND '$end_date'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Create new Spreadsheet
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set the column headers
        $sheet->setCellValue('A1', 'Date');
        $sheet->setCellValue('B1', 'Modem Vendor');
        $sheet->setCellValue('C1', 'MAC Address');
        $sheet->setCellValue('D1', 'Reported Issue (Complaint)');
        $sheet->setCellValue('E1', 'Power Status');
        $sheet->setCellValue('F1', 'Booting Status');
        $sheet->setCellValue('G1', 'LAN Port Status');
        $sheet->setCellValue('H1', 'WLAN Status');
        $sheet->setCellValue('I1', 'Web Login');
        $sheet->setCellValue('J1', 'Comment');
        $sheet->setCellValue('K1', 'Entered By');

        // Populate the rows with data
        $row = 2;
        while ($data = $result->fetch_assoc()) {
            $sheet->setCellValue('A' . $row, $data['complaint_date']);
            $sheet->setCellValue('B' . $row, $data['modem_vendor']);
            $sheet->setCellValue('C' . $row, $data['mac_address']);
            $sheet->setCellValue('D' . $row, $data['complaint_type']);
            $sheet->setCellValue('E' . $row, $data['power_status']);
            $sheet->setCellValue('F' . $row, $data['booting_status']);
            $sheet->setCellValue('G' . $row, $data['lan_port_status']);
            $sheet->setCellValue('H' . $row, $data['wlan_status']);
            $sheet->setCellValue('I' . $row, $data['web_login']);
            $sheet->setCellValue('J' . $row, $data['comment']);
            $sheet->setCellValue('K' . $row, $data['entered_by']);
            $row++;
        }

        // Write the file
        $writer = new Xlsx($spreadsheet);
        $fileName = "Complaint_Data_" . date('Ymd') . ".xlsx";

        // Send file to browser for download
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header("Content-Disposition: attachment; filename=\"$fileName\"");
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
    } else {
        echo "No data found for the selected date range.";
    }
}

$conn->close();
?>
