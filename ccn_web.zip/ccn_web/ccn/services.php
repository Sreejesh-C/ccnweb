<?php
session_start();
if ($_SESSION['role'] != 'services') {
    header('Location: login.php');
    exit;
}

// Include database connection
include 'db.php'; // Assuming db.php contains your database connection code

$search_results = '';
$mac_address = $operator_id = $complaint_type = $complaint_status = '';
$success_message = '';
$error_message = '';

// Handle modem search
if (isset($_POST['search'])) {
    $search_mac = $_POST['search_mac'];

    // Search for the modem by MAC address
    $sql = "SELECT * FROM modems WHERE mac_address = '$search_mac'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Modem found, display the details
        $modem = $result->fetch_assoc();
        $mac_address = $modem['mac_address'];
        $operator_id = $modem['operator_id'];
        
        // Fetch complaint details if any
        $complaint_sql = "SELECT * FROM complaints WHERE mac_address = '$mac_address'";
        $complaint_result = $conn->query($complaint_sql);
        if ($complaint_result->num_rows > 0) {
            $complaint = $complaint_result->fetch_assoc();
            $complaint_type = $complaint['complaint_type'];
            $complaint_status = $complaint['Complaint_status']; // Good or Bad

            // Check if the complaint has already been resolved
            if ($complaint_status == 'Good' || $complaint_status == 'Bad') {
                $success_message = "Complaint for MAC address $mac_address has already been updated as '$complaint_status'.";
            }
        } else {
            $error_message = "No complaint found for this modem.";
        }
    } else {
        $error_message = "No modem found with the given MAC address.";
    }
}

// Handle complaint submission or update
if (isset($_POST['submit_complaint'])) {
    $mac_address = $_POST['search_mac'];

    // Check if a complaint for this MAC address already exists
    $check_sql = "SELECT * FROM complaints WHERE mac_address = '$mac_address'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        // Complaint already exists, update the existing row
        $update_sql = "UPDATE complaints SET 
                        complaint_type = 'New Complaint',
                        `Complaint_status` = 'Open'
                        WHERE mac_address = '$mac_address'";
        if ($conn->query($update_sql) === TRUE) {
            $success_message = "Complaint updated successfully!";
        } else {
            $error_message = "Error updating complaint: " . $conn->error;
        }
    } else {
        // No existing complaint, insert a new one
        $insert_sql = "INSERT INTO complaints (mac_address, complaint_type, Complaint_status) 
                       VALUES ('$mac_address', 'New Complaint', 'Open')";
        if ($conn->query($insert_sql) === TRUE) {
            $success_message = "Complaint registered successfully!";
        } else {
            $error_message = "Error registering complaint: " . $conn->error;
        }
    }
}

// Handle complaint update (Edit existing complaint)
if (isset($_POST['update_complaint'])) {
    $mac_address = $_POST['mac_address'];
    $complaint_type = $_POST['complaint_type'];
    $power_status = $_POST['power_status'];
    $booting_status = $_POST['booting_status'];
    $lan_port_status = $_POST['lan_port_status'];
    $wlan_status = $_POST['wlan_status'];
    $web_login = $_POST['web_login'];
    $comment = $_POST['comment'];
    $compst = $_POST['Complaint_status']; // Dropdown value for Complaint Status
    $user_login = $_SESSION['username']; // Get current logged-in user

    // Update complaint in the complaints table
    $update_sql = "UPDATE complaints SET 
                    complaint_type = '$complaint_type',
                    power_status = '$power_status',
                    booting_status = '$booting_status',
                    lan_port_status = '$lan_port_status',
                    wlan_status = '$wlan_status',
                    web_login = '$web_login',
                    `Complaint_status` = '$compst',
                    comment = '$comment',
                    user_login = '$user_login'
                    WHERE mac_address = '$mac_address'";
    
    if ($conn->query($update_sql) === TRUE) {
        $success_message = "Complaint updated successfully!";
    } else {
        $error_message = "Error updating complaint: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="logout-container">
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <div class="dashboard-content">
        <h2>Services Dashboard</h2>
        <p>Hello, <?php echo $_SESSION['username']; ?>!</p>

        <!-- Display error or success messages -->
        <?php if ($success_message): ?>
            <p class="message success"><?php echo $success_message; ?></p>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <p class="message error"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <!-- Search Modem Form -->
        <div class="search-container">
            <h3>Search Modem</h3>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="search_mac">MAC Address</label>
                    <input type="text" id="search_mac" name="search_mac" class="input-field" placeholder="Enter MAC Address" required>
                </div>
                <div class="button-container">
                    <button type="submit" name="search">Search</button>
                    <button type="submit" name="submit_complaint">Register Complaint</button>
                    <button type="reset" onclick="window.location.reload()">Reset</button> <!-- Reset button -->
                </div>
            </form>
        </div>

        <!-- Display Modem Details if Found -->
        <?php if ($mac_address && $operator_id): ?>
            <div class="modem-details">
                <h3>Modem Details</h3>
                <p>MAC Address: <?php echo $mac_address; ?></p>
                <p>Operator ID: <?php echo $operator_id; ?></p>

                <?php if ($complaint_status == 'Good' || $complaint_status == 'Bad'): ?>
                    <p>Complaint Status: <?php echo $complaint_status; ?></p>
                    <p>Complaint Type: <?php echo $complaint_type; ?></p>
                <?php else: ?>
                    <!-- Complaint Form for Updates -->
                    <div class="complaint-container">
                        <h3>Edit Complaint Details</h3>
                        <form method="POST" action="">
                            <input type="hidden" name="mac_address" value="<?php echo $mac_address; ?>">
                            <div class="form-group">
                                <label for="complaint_type">Complaint Type</label>
                                <input type="text" id="complaint_type" name="complaint_type" class="input-field" value="<?php echo $complaint_type; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="power_status">Power Status</label>
                                <input type="text" id="power_status" name="power_status" class="input-field" required>
                            </div>
                            <div class="form-group">
                                <label for="booting_status">Booting Status</label>
                                <input type="text" id="booting_status" name="booting_status" class="input-field" required>
                            </div>
                            <div class="form-group">
                                <label for="lan_port_status">LAN Port Status</label>
                                <input type="text" id="lan_port_status" name="lan_port_status" class="input-field" required>
                            </div>
                            <div class="form-group">
                                <label for="wlan_status">WLAN Status</label>
                                <input type="text" id="wlan_status" name="wlan_status" class="input-field" required>
                            </div>
                            <div class="form-group">
                                <label for="web_login">Web Login</label>
                                <input type="text" id="web_login" name="web_login" class="input-field" required>
                            </div>
                            <div class="form-group">
                                <label for="comment">Comment</label>
                                <textarea id="comment" name="comment" class="input-field" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="Complaint_status">Complaint Status</label>
                                <select id="Complaint_status" name="Complaint_status" class="input-field" required>
                                    <option value="Good">Good</option>
                                    <option value="Bad">Bad</option>
                                </select>
                            </div>
                            <div class="button-container">
                                <button type="submit" name="update_complaint">Update Complaint</button>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
