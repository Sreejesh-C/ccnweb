<?php
session_start();
if ($_SESSION['role'] != 'customercare') {
    header('Location: login.php');
    exit;
}

// Include database connection
include 'db.php'; // Assuming db.php contains your database connection code

// Initialize variables
$search_results = '';
$modem_details = '';
$complaint_details = '';
$all_complaints = [];

// Handle search
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['search'])) {
        $search_mac = $_POST['search_mac'];
        $search_operator_id = $_POST['search_operator_id'];

        // Search for the modem by MAC address or Operator ID
        $sql = "SELECT * FROM modems WHERE mac_address = '$search_mac' OR operator_id = '$search_operator_id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Modem found, display the details
            $modem_details = $result->fetch_assoc();

            // Fetch complaints related to the modem's MAC address
            $mac_address = $modem_details['mac_address'];
            $complaint_sql = "SELECT * FROM complaints WHERE mac_address = '$mac_address'";
            $complaint_result = $conn->query($complaint_sql);

            if ($complaint_result->num_rows > 0) {
                $complaint_details = $complaint_result->fetch_all(MYSQLI_ASSOC);
            } else {
                $complaint_details = 'No complaints found for this modem.';
            }
        } else {
            $search_results = 'No modem found with the given MAC address or Operator ID.';
        }
    }

    // Handle display of all complaints for a specific date range
    if (isset($_POST['display_complaints'])) {
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];

        // SQL query to include modem details via a JOIN
        $display_sql = "
            SELECT complaints.*, modems.operator_id, modems.modem_vendor, modems.mac_address AS modem_mac 
            FROM complaints 
            JOIN modems ON complaints.mac_address = modems.mac_address 
            WHERE complaints.complaint_date BETWEEN '$start_date' AND '$end_date'
        ";
        $all_complaints = $conn->query($display_sql)->fetch_all(MYSQLI_ASSOC);
    }

    // Handle sending all "bad" complaints to services
    if (isset($_POST['send_all_to_services'])) {
        $update_sql = "UPDATE complaints SET Complaint_status = 'sent to services' WHERE Complaint_status = 'bad'";
        if ($conn->query($update_sql) === TRUE) {
            $search_results = "All 'bad' complaints sent to services successfully!";
        } else {
            $search_results = "Error sending complaints: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customer Care Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Logout Button in the Top Left Corner -->
    <div class="logout-container">
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <div class="dashboard-content">
        <h2>Customer Care - Search Modem and Complaint Details</h2>

        <!-- Search Form -->
        <div class="search-container">
            <form method="POST" action="">
                <div class="form-group">
                    <label for="search_mac">MAC Address</label>
                    <input type="text" id="search_mac" name="search_mac" class="input-field" placeholder="Enter MAC Address">
                </div>
                <div class="form-group">
                    <label for="search_operator_id">Operator ID</label>
                    <input type="text" id="search_operator_id" name="search_operator_id" class="input-field" placeholder="Enter Operator ID">
                </div>
                <div class="button-container">
                    <button type="submit" name="search">Search</button>
                </div>
            </form>
        </div>

        <!-- Display search results and modem details -->
        <?php if ($modem_details): ?>
            <div class="modem-details">
                <h3>Modem Details</h3>
                <table>
                    <tr>
                        <th>Operator ID</th>
                        <th>Modem Vendor</th>
                        <th>MAC Address</th>
                    </tr>
                    <tr>
                        <td><?php echo htmlspecialchars($modem_details['operator_id']); ?></td>
                        <td><?php echo htmlspecialchars($modem_details['modem_vendor']); ?></td>
                        <td><?php echo htmlspecialchars($modem_details['mac_address']); ?></td>
                    </tr>
                </table>
            </div>

            <!-- Display Complaint Details -->
            <div class="complaint-details">
                <h3>Complaint Details</h3>
                <?php if (is_array($complaint_details)): ?>
                    <table>
                        <tr>
                            <th>Complaint Type</th>
                            <th>Complaint Date</th>
                            <th>Power Status</th>
                            <th>Booting Status</th>
                            <th>LAN Port Status</th>
                            <th>WLAN Status</th>
                            <th>Web Login</th>
                            <th>Comment</th>
                            <th>Entered By</th>
                            <th>Status</th>
                        </tr>
                        <?php foreach ($complaint_details as $complaint): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($complaint['complaint_type']); ?></td>
                                <td><?php echo htmlspecialchars($complaint['complaint_date']); ?></td>
                                <td><?php echo htmlspecialchars($complaint['power_status']); ?></td>
                                <td><?php echo htmlspecialchars($complaint['booting_status']); ?></td>
                                <td><?php echo htmlspecialchars($complaint['lan_port_status']); ?></td>
                                <td><?php echo htmlspecialchars($complaint['wlan_status']); ?></td>
                                <td><?php echo htmlspecialchars($complaint['web_login']); ?></td>
                                <td><?php echo htmlspecialchars($complaint['comment']); ?></td>
                                <td><?php echo htmlspecialchars($complaint['user_login']); ?></td>
                                <td><?php echo htmlspecialchars($complaint['Complaint_status']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                <?php else: ?>
                    <p><?php echo $complaint_details; ?></p>
                <?php endif; ?>
            </div>
        <?php elseif ($search_results): ?>
            <p class="message error"><?php echo $search_results; ?></p>
        <?php endif; ?>

        <!-- Display All Complaints Form -->
        <div class="display-container">
            <h3>Display All Complaints</h3>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="start_date">Start Date</label>
                    <input type="date" name="start_date" id="start_date" required>
                </div>
                <div class="form-group">
                    <label for="end_date">End Date</label>
                    <input type="date" name="end_date" id="end_date" required>
                </div>
                <div class="button-container">
                    <button type="submit" name="display_complaints">Display Complaints</button>
                </div>
            </form>
        </div>

        <!-- Display All Complaints if Found -->
        <?php if (!empty($all_complaints)): ?>
            <div class="all-complaints">
                <h3>All Complaints</h3>
                <table>
                    <tr>
                        <th>Operator ID</th>
                        <th>Modem Vendor</th>
                        <th>Complaint Type</th>
                        <th>Complaint Date</th>
                        <th>Power Status</th>
                        <th>Booting Status</th>
                        <th>LAN Port Status</th>
                        <th>WLAN Status</th>
                        <th>Web Login</th>
                        <th>Comment</th>
                        <th>Entered By</th>
                        <th>Status</th>
                    </tr>
                    <?php foreach ($all_complaints as $complaint): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($complaint['operator_id']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['modem_vendor']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['complaint_type']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['complaint_date']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['power_status']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['booting_status']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['lan_port_status']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['wlan_status']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['web_login']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['comment']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['user_login']); ?></td>
                            <td><?php echo htmlspecialchars($complaint['Complaint_status']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        <?php endif; ?>

        <!-- Send all "bad" complaints to services -->
        <div class="send-to-services">
            <form method="POST" action="">
                <button type="submit" name="send_all_to_services">Send All Bad Complaints to Services</button>
            </form>
        </div>

    </div>
</body>
</html>
