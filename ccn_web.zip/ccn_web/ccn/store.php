<?php
session_start();
if ($_SESSION['role'] != 'store') {
    header('Location: login.php');
    exit;
}

// Include database connection
include 'db.php'; // Assuming db.php contains your database connection code

// Initialize messages and variables for form values
$message = '';
$search_results = [];
$complaint_message = '';
$operator_id = $modem_vendor = $mac_address = $modem_serial_number = '';

// Handle modem details submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['search']) && !isset($_POST['submit_complaint'])) {
    $operator_id = $_POST['operator_id'];
    $modem_vendor = $_POST['modem_vendor'];
    $mac_address = $_POST['mac_address'];
    $modem_serial_number = $_POST['modem_serial_number']; // Added field

    // Insert data into modems table
    $sql = "INSERT INTO modems (operator_id, modem_vendor, mac_address, modem_serial_number) VALUES ('$operator_id', '$modem_vendor', '$mac_address', '$modem_serial_number')";
    if ($conn->query($sql) === TRUE) {
        $message = "Data saved successfully!";
        // Clear form inputs after successful submission
        $operator_id = $modem_vendor = $mac_address = $modem_serial_number = '';
    } else {
        // Check for duplicate entry error (error code 1062 in MySQL)
        if ($conn->errno == 1062) {
            $message = "Error: This modem has already been added.";
        } else {
            // Other errors
            $message = "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Handle modem search
if (isset($_POST['search'])) {
    $search_mac = $_POST['search_mac'];
    $search_operator_id = $_POST['search_operator_id'];

    if (!empty($search_operator_id)) {
        // Search for modems by Operator ID
        $sql = "SELECT * FROM modems WHERE operator_id = '$search_operator_id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Modems found, store details in an array
            while ($row = $result->fetch_assoc()) {
                $search_results[] = $row;
            }
        } else {
            $search_results = "No modems found with the given Operator ID.";
        }
    } elseif (!empty($search_mac)) {
        // Search for the modem by MAC address
        $sql = "SELECT * FROM modems WHERE mac_address = '$search_mac'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Modem found, display the details
            $row = $result->fetch_assoc();
            $mac_address = $row['mac_address'];
            $operator_id = $row['operator_id'];
            $modem_serial_number = $row['modem_serial_number']; // Fetching serial number
            $search_results[] = $row; // Add single result to array
        } else {
            $search_results = "No modem found with the given MAC address.";
        }
    } else {
        $search_results = "Please enter a MAC address or an Operator ID.";
    }
}

// Handle complaint submission
if (isset($_POST['submit_complaint'])) {
    $complaint_type = $_POST['complaint_type'];
    $mac_address = $_POST['mac_address'];

    // Insert complaint into the complaints table
    $sql = "INSERT INTO complaints (mac_address, complaint_type) VALUES ('$mac_address', '$complaint_type')";
    if ($conn->query($sql) === TRUE) {
        $complaint_message = "Complaint submitted successfully!";
    } else {
        $complaint_message = "Error: " . $conn->error;
    }
}

// Close the database connection after all operations
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Logout Button in the Top Left Corner -->
    <div class="logout-container">
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <div class="dashboard-content">
        <h2>Welcome to the Store Dashboard</h2>
        <p>Hello, <?php echo $_SESSION['username']; ?>!</p>

        <!-- Display message after form submission -->
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>

        <!-- Modem Details Form -->
        <div class="dashboard-container">
            <h2>Enter Modem Details</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="operator_id">Operator ID</label>
                    <input type="text" id="operator_id" name="operator_id" class="input-field" placeholder="Enter Operator ID" value="<?php echo htmlspecialchars($operator_id); ?>" required>
                </div>
                <div class="form-group">
                    <label for="modem_vendor">Modem Vendor</label>
                    <input type="text" id="modem_vendor" name="modem_vendor" class="input-field" placeholder="Enter Modem Vendor" value="<?php echo htmlspecialchars($modem_vendor); ?>" required>
                </div>
                <div class="form-group">
                    <label for="mac_address">Modem MAC Address</label>
                    <input type="text" id="mac_address" name="mac_address" class="input-field" placeholder="Enter Modem MAC Address" value="<?php echo htmlspecialchars($mac_address); ?>" required>
                </div>
                <div class="form-group">
                    <label for="modem_serial_number">Modem Serial Number</label>
                    <input type="text" id="modem_serial_number" name="modem_serial_number" class="input-field" placeholder="Enter Modem Serial Number" value="<?php echo htmlspecialchars($modem_serial_number); ?>" required>
                </div>
                <div class="button-container">
                    <button type="submit">Submit</button>
                </div>
            </form>
        </div>

        <!-- Search Form -->
        <div class="search-container">
            <h3>Search Modem</h3>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="search_mac">MAC Address</label>
                    <input type="text" id="search_mac" name="search_mac" class="input-field" placeholder="Enter MAC Address">
                </div>
                <div class="form-group">
                    <label for="search_operator_id">Operator ID</label>
                    <input type="text" id="search_operator_id" name="search_operator_id" class="input-field" placeholder="Enter Operator ID">
                </div>
                <div class="button-container">
                    <button type="submit" name="search">Search</button>
                </div>
            </form>
        </div>

        <!-- Display search results and modem details -->
        <?php if (!empty($search_results)): ?>
            <h3>Search Results</h3>
            <?php if (is_array($search_results)): ?>
                <table>
                    <tr>
                        <th>Operator ID</th>
                        <th>Modem Vendor</th>
                        <th>MAC Address</th>
                        <th>Modem Serial Number</th>
                    </tr>
                    <?php foreach ($search_results as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['operator_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['modem_vendor']); ?></td>
                            <td><?php echo htmlspecialchars($row['mac_address']); ?></td>
                            <td><?php echo htmlspecialchars($row['modem_serial_number']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php else: ?>
                <p class="message"><?php echo $search_results; ?></p>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Complaint Form -->
        <?php if ($mac_address && $operator_id): ?>
            <div class="complaint-container">
                <h3>Enter Complaint for Modem (MAC: <?php echo htmlspecialchars($mac_address); ?>)</h3>
                <form method="POST" action="">
                    <input type="hidden" name="mac_address" value="<?php echo htmlspecialchars($mac_address); ?>">
                    <div class="form-group">
                        <label for="complaint_type">Complaint Type</label>
                        <input type="text" id="complaint_type" name="complaint_type" class="input-field" placeholder="Enter Complaint Type" required>
                    </div>
                    <div class="button-container">
                        <button type="submit" name="submit_complaint">Submit Complaint</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>