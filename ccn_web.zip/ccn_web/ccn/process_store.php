<?php
// process_store.php
include 'db.php';  // Include the database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $operator_id = $_POST['operator_id'];
    $modem_vendor = $_POST['modem_vendor'];
    $mac_address = $_POST['mac_address'];

    $sql = "INSERT INTO modems (operator_id, modem_vendor, mac_address) VALUES ('$operator_id', '$modem_vendor', '$mac_address')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Modem details added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
